/*require(['jquery'], function ($) {
    'use strict';
    console.log('Custom JS loaded');
});*/
require(['js/slider-init'], function (initSlider) {
    initSlider();
});

