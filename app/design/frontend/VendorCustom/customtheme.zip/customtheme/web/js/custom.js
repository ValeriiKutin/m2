require(['customSlider'], function(initSlider){
    initSlider(); // Ініціалізація слайдера
});
